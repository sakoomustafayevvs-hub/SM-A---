import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.smglobal.smai',
  appName: 'SM AI',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
