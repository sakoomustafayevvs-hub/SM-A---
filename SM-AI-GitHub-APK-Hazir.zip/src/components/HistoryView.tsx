import React, { useState } from 'react';
import {
  History,
  MessageSquare,
  PlusCircle,
  Trash2,
  Search,
  Download,
  ArrowRight,
  Clock,
  Sparkles,
} from 'lucide-react';
import { ChatSession } from '../types';

interface HistoryViewProps {
  sessions: ChatSession[];
  activeSessionId: string;
  onSelectSession: (id: string) => void;
  onDeleteSession: (id: string) => void;
  onClearAllSessions: () => void;
  onNewChat: () => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  sessions,
  activeSessionId,
  onSelectSession,
  onDeleteSession,
  onClearAllSessions,
  onNewChat,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSessions = sessions.filter(
    (s) =>
      s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.messages.some((m) => m.content.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleExportSession = (session: ChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    const exportData = {
      title: session.title,
      createdAt: session.createdAt,
      messages: session.messages,
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sm_ai_chat_${session.id}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="pb-24 pt-4 px-4 max-w-md mx-auto space-y-4">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-amber-300 flex items-center gap-2">
            <History className="w-5 h-5 text-amber-400" /> Söhbət Tarixçəsi
          </h2>
          <p className="text-[11px] text-zinc-400">Keçmiş AI söhbətlərinizi idarə edin</p>
        </div>

        <button
          onClick={onNewChat}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-black font-bold text-xs shadow-xs hover:brightness-110 active:scale-95 transition"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Yeni Chat</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Tarixçədə axtarış et..."
          className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-9 pr-4 py-2 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-400"
        />
      </div>

      {/* Sessions List */}
      <div className="space-y-2.5">
        {filteredSessions.length === 0 ? (
          <div className="p-8 text-center bg-zinc-900/50 border border-zinc-800 rounded-2xl space-y-2">
            <MessageSquare className="w-8 h-8 text-zinc-600 mx-auto" />
            <p className="text-xs text-zinc-400">Heç bir söhbət tapılmadı.</p>
            <button
              onClick={onNewChat}
              className="text-xs text-amber-400 font-semibold hover:underline"
            >
              Yeni söhbət başlada bilərsiniz.
            </button>
          </div>
        ) : (
          filteredSessions.map((session) => {
            const isActive = session.id === activeSessionId;
            const messageCount = session.messages.length;
            const lastMessage = session.messages[session.messages.length - 1]?.content || 'Boş söhbət';

            return (
              <div
                key={session.id}
                onClick={() => onSelectSession(session.id)}
                className={`p-3.5 rounded-2xl border cursor-pointer transition-all duration-200 flex items-center justify-between group ${
                  isActive
                    ? 'bg-amber-500/10 border-amber-400/80 shadow-md'
                    : 'bg-zinc-900/80 border-zinc-800 hover:border-amber-500/30 hover:bg-zinc-800/80'
                }`}
              >
                <div className="space-y-1 pr-2 max-w-[80%]">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-zinc-100 group-hover:text-amber-300 truncate">
                      {session.title || 'Yeni Söhbət'}
                    </span>
                    {isActive && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-400 text-black font-bold">
                        Aktiv
                      </span>
                    )}
                  </div>

                  <p className="text-[11px] text-zinc-400 line-clamp-1 italic">
                    "{lastMessage}"
                  </p>

                  <div className="flex items-center gap-3 text-[10px] text-zinc-500 pt-0.5">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {session.updatedAt}
                    </span>
                    <span>•</span>
                    <span>{messageCount} mesaj</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={(e) => handleExportSession(session, e)}
                    title="JSON kopyasını yüklə"
                    className="p-1.5 rounded-lg text-zinc-400 hover:text-amber-300 hover:bg-zinc-800 transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm('Bu söhbəti silmək istədiyinizdən əminsiniz?')) {
                        onDeleteSession(session.id);
                      }
                    }}
                    title="Söhbəti Sil"
                    className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-zinc-800 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Clear All Option */}
      {sessions.length > 0 && (
        <div className="pt-2 text-center">
          <button
            onClick={() => {
              if (confirm('Bütün söhbət tarixçəsini sıfırlamaq istəyirsiniz?')) {
                onClearAllSessions();
              }
            }}
            className="text-xs text-rose-400/80 hover:text-rose-400 hover:underline inline-flex items-center gap-1 font-medium"
          >
            <Trash2 className="w-3.5 h-3.5" /> Bütün Tarixçəni Sil
          </button>
        </div>
      )}
    </div>
  );
};
