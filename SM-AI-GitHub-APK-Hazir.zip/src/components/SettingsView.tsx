import React, { useState, useEffect } from 'react';
import {
  Settings,
  Globe,
  Moon,
  Sun,
  Cpu,
  ShieldCheck,
  Check,
  Info,
  Key,
  Smartphone,
  ExternalLink,
} from 'lucide-react';
import { LANGUAGE_LABEL_MAP } from '../data/prompts';
import logoImg from '../assets/images/sm_ai_logo_1786303544354.jpg';

interface SettingsViewProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  selectedLanguage: string;
  setSelectedLanguage: (lang: string) => void;
  selectedModel: string;
  setSelectedModel: (model: string) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  darkMode,
  setDarkMode,
  selectedLanguage,
  setSelectedLanguage,
  selectedModel,
  setSelectedModel,
}) => {
  const [apiStatus, setApiStatus] = useState<{ hasKey: boolean; appName: string } | null>(null);

  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        setApiStatus({
          hasKey: data.hasApiKey,
          appName: data.appName || 'SM AI',
        });
      })
      .catch(() => {
        setApiStatus({ hasKey: false, appName: 'SM AI' });
      });
  }, []);

  return (
    <div className="pb-24 pt-4 px-4 max-w-md mx-auto space-y-5">
      {/* Header */}
      <div>
        <h2 className="text-base font-bold text-amber-300 flex items-center gap-2">
          <Settings className="w-5 h-5 text-amber-400" /> Tətbiq Ayarları
        </h2>
        <p className="text-[11px] text-zinc-400">SM AI tətbiq parametrlərini fərdiləşdirin</p>
      </div>

      {/* Language Selector */}
      <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-3">
        <label className="text-xs font-bold text-zinc-200 flex items-center gap-2">
          <Globe className="w-4 h-4 text-amber-400" /> Ana Cavab Dili
        </label>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(LANGUAGE_LABEL_MAP).map(([code, lang]) => (
            <button
              key={code}
              onClick={() => setSelectedLanguage(code)}
              className={`p-2.5 rounded-xl text-xs font-semibold flex items-center justify-between border transition ${
                selectedLanguage === code
                  ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                  : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <span className="flex items-center gap-2">
                <span>{lang.flag}</span>
                <span>{lang.name}</span>
              </span>
              {selectedLanguage === code && <Check className="w-3.5 h-3.5 text-amber-400" />}
            </button>
          ))}
        </div>
      </div>

      {/* Dark / Light Theme */}
      <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-between">
        <div>
          <p className="text-xs font-bold text-zinc-200 flex items-center gap-2">
            {darkMode ? <Moon className="w-4 h-4 text-amber-400" /> : <Sun className="w-4 h-4 text-amber-400" />}
            Mövzu (Theme)
          </p>
          <p className="text-[10px] text-zinc-400 mt-0.5">Tünd (Dark Gold) rejim standartdır</p>
        </div>

        <button
          onClick={() => setDarkMode(!darkMode)}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition ${
            darkMode
              ? 'bg-amber-500/20 border-amber-400 text-amber-300'
              : 'bg-zinc-800 border-zinc-700 text-zinc-300'
          }`}
        >
          {darkMode ? 'Tünd Rejim' : 'Açıq Rejim'}
        </button>
      </div>

      {/* Model Selection */}
      <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-3">
        <label className="text-xs font-bold text-zinc-200 flex items-center gap-2">
          <Cpu className="w-4 h-4 text-amber-400" /> AI Modeli
        </label>
        <div className="space-y-2">
          {[
            { id: 'gemini-3.6-flash', name: 'Gemini 3.6 Flash', desc: 'Ultra sürətli, yüksək intellektli model' },
            { id: 'gemini-3.1-pro-preview', name: 'Gemini 3.1 Pro', desc: 'Dərin kod və mürəkkəb mühakimə' },
          ].map((m) => (
            <button
              key={m.id}
              onClick={() => setSelectedModel(m.id)}
              className={`w-full p-3 rounded-xl text-left border transition flex items-center justify-between ${
                selectedModel === m.id
                  ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                  : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <div>
                <p className="text-xs font-bold text-zinc-100">{m.name}</p>
                <p className="text-[10px] text-zinc-500">{m.desc}</p>
              </div>
              {selectedModel === m.id && <Check className="w-4 h-4 text-amber-400 shrink-0" />}
            </button>
          ))}
        </div>
      </div>

      {/* Standalone HTML Export Section */}
      <div className="p-4 rounded-2xl bg-zinc-900 border border-amber-500/30 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-amber-300 flex items-center gap-2">
            <Globe className="w-4 h-4 text-amber-400" /> Tək Fayl HTML Versiyası (Standalone)
          </span>
          <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold">
            100% Sərbəst
          </span>
        </div>
        <p className="text-[11px] text-zinc-400 leading-relaxed">
          Tətbiqin bütün dizayn və funksionallığını özündə saxlayan tək <strong>.html</strong> faylını endirin və ya brauzerdə açın.
        </p>
        <div className="flex gap-2">
          <a
            href="/sm_ai_app.html"
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 py-2.5 px-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-amber-500/20 transition"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Brauzerdə Aç</span>
          </a>
          <a
            href="/sm_ai_app.html"
            download="sm_ai_app.html"
            className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-black text-xs font-bold flex items-center justify-center gap-1.5 hover:brightness-110 transition shadow-md"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>.HTML Yüklə</span>
          </a>
        </div>
      </div>

      {/* Backend API Connection Status */}
      <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-zinc-200 flex items-center gap-2">
            <Key className="w-4 h-4 text-amber-400" /> Təhlükəsiz Server Bağlantısı
          </span>
          <span
            className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
              apiStatus?.hasKey
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
            }`}
          >
            {apiStatus?.hasKey ? 'Canlı Rejim (Active)' : 'Demo Rejimi (Demo)'}
          </span>
        </div>
        <p className="text-[11px] text-zinc-400 leading-relaxed">
          Sizin API açarınız heç vaxt brauzerdə görünmür. Bütün müraciətlər təhlükəsiz backend endpoint-ləri vasitəsilə emal olunur.
        </p>
      </div>

      {/* About SM Global */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-zinc-900 via-amber-950/20 to-zinc-900 border border-amber-500/30 text-center space-y-3">
        <img
          src={logoImg}
          alt="SM AI Logo"
          className="w-12 h-12 rounded-full mx-auto object-cover border border-amber-400 shadow-md"
          referrerPolicy="no-referrer"
        />
        <div>
          <h3 className="text-sm font-bold text-amber-300">SM AI (v2.5 Mobile)</h3>
          <p className="text-xs text-zinc-400">Powered by SM Global Intelligence</p>
        </div>
        <p className="text-[11px] text-zinc-400 leading-relaxed max-w-xs mx-auto">
          Android mobil telefonlar üçün optimallaşdırılmış premium AI təcrübəsi.
        </p>
        <div className="pt-1 text-[10px] text-amber-400/80 font-mono">
          © 2026 SM Global. Bütün hüquqlar qorunur.
        </div>
      </div>
    </div>
  );
};
