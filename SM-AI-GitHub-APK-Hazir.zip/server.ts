import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;

function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "25mb" }));

  // Health check endpoint
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      appName: "SM AI",
      company: "SM Global",
      hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    });
  });

  // AI Chat Endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const {
        messages,
        systemInstruction,
        language = "az",
        model = "gemini-3.6-flash",
        image,
        fileContent,
      } = req.body;

      if (!messages || !Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ error: "Sual və ya mesaj daxil edilməyib." });
      }

      const ai = getGeminiClient();

      if (!ai) {
        // Fallback friendly AI response when key is missing on backend
        const lastUserMsg = messages[messages.length - 1]?.content || "";
        return res.json({
          response: `[SM AI - Demo Mode]\n\nSalam! Mən SM Global tərəfindən hazırlanmış SM AI köməkçisiyəm.\n\nCavabınız: "${lastUserMsg}" mövzusunu aldım. Təhlükəsiz AI server rejimi aktivdir. Tam canlı Gemini cavabları üçün Settings (Ayarlar) bölməsində öz API açarınızı daxil edə bilərsiniz və ya platforma tərəfindən verilmiş açardan istifadə olunur.\n\nSM Global Intelligence sizin xidmətinizdədir!`,
          isDemo: true,
        });
      }

      const defaultSystemPrompt = `Sən SM Global şirkətinin yaratdığı "SM AI" adlı ultra-müasir və peşəkar süni intellekt köməkçisisən (SM Global Intelligence).
Sən istifadəçi hansı dildə yazırsa (xüsusilə Azərbaycan dili, Türk dili, İngilis dili və s.) həmin dildə dəqiq, mədəni, əhatəli və peşəkar cavablar verirsən.

Bilik sahələrin:
1. Real söhbət və sual-cavab
2. Kod yazmaq (JavaScript, Python, C++, HTML/CSS, React, SQL və s.) və kodu xəta-xəta izah etmək
3. Mətnlər yaratmaq, esse, məqalə, e-poçt, xülasə yazmaq və mətn redaktəsi
4. Tərcüməçi - dildən dilə dəqiq, təbii tərcümə
5. Biznes ideyaları, startap strategiyaları, marketinq planları və maliyyə model təklifləri
6. Fayl və şəkilləri analiz etmək
7. Səsli ünsiyyət üçün qısa və səlis cavablar

Daim nəzakətli, intellektual və brendə layiq dildə cavab ver. Cavablarında lazımi yerlərdə markdown formatından (kod blokları, siyahılar, qalın şriftlər) istifadə et.`;

      const activeSystemInstruction = systemInstruction || defaultSystemPrompt;

      // Construct history / content array
      const contents: any[] = [];

      // Add conversation history
      for (const msg of messages) {
        const role = msg.role === "user" ? "user" : "model";
        const parts: any[] = [{ text: msg.content }];
        
        // Handle inline image if present on last message
        if (msg === messages[messages.length - 1] && image?.base64 && image?.mimeType) {
          parts.unshift({
            inlineData: {
              data: image.base64.replace(/^data:image\/\w+;base64,/, ""),
              mimeType: image.mimeType,
            },
          });
        }

        // Handle attached text/file content
        if (msg === messages[messages.length - 1] && fileContent) {
          parts.push({
            text: `\n\n--- Yüklənmiş Fayl Mətn Məzmunu (${fileContent.fileName || "Fayl"}) ---\n${fileContent.text}`,
          });
        }

        contents.push({ role, parts });
      }

      let responseText = "";
      try {
        const response = await ai.models.generateContent({
          model: model || "gemini-3.6-flash",
          contents: contents.length === 1 ? contents[0].parts : contents,
          config: {
            systemInstruction: activeSystemInstruction,
            temperature: 0.7,
          },
        });
        responseText = response.text || "";
      } catch (err: any) {
        console.warn("Primary Gemini model rate limited or error, attempting secondary fallback:", err?.message);
        // Fallback to gemini-2.0-flash or gemini-1.5-flash if primary model is rate-limited
        try {
          const fallbackResponse = await ai.models.generateContent({
            model: "gemini-2.0-flash",
            contents: contents.length === 1 ? contents[0].parts : contents,
            config: {
              systemInstruction: activeSystemInstruction,
              temperature: 0.7,
            },
          });
          responseText = fallbackResponse.text || "";
        } catch (fallbackErr: any) {
          try {
            const fallbackResponse15 = await ai.models.generateContent({
              model: "gemini-1.5-flash",
              contents: contents.length === 1 ? contents[0].parts : contents,
              config: {
                systemInstruction: activeSystemInstruction,
                temperature: 0.7,
              },
            });
            responseText = fallbackResponse15.text || "";
          } catch (err15: any) {
            console.warn("Fallback model error:", fallbackErr?.message);
            responseText = "Sizə kömək etməyə hazıram! Lütfən sualınızı verin.";
          }
        }
      }

      if (!responseText) {
        responseText = "Salam! Mən SM AI. Tələbinizi emal etmək üçün lütfən yenidən sualınızı verin.";
      }

      return res.json({ response: responseText, isDemo: false });
    } catch (error: any) {
      console.error("Gemini Chat API Error:", error);
      return res.json({
        response: "SM AI serverində qısamüddətli yenilənmə gedir. Lütfən bir az sonra yenidən cəhd edin.",
        isDemo: true,
      });
    }
  });

  // AI Image Generation Endpoint
  app.post("/api/generate-image", async (req, res) => {
    try {
      const { prompt, aspectRatio = "1:1", style = "Futuristic" } = req.body;

      if (!prompt) {
        return res.status(400).json({ error: "Şəkil üçün təsvir (prompt) daxil edin." });
      }

      const ai = getGeminiClient();

      const enhancedPrompt = `SM AI Global Intelligence styled image generation. ${style} style: ${prompt}. High quality, detailed, golden dark luxury aesthetic.`;

      if (!ai) {
        // Return a rich SVG stylized placeholder when backend key is absent
        const encodedPrompt = encodeURIComponent(prompt.substring(0, 40));
        return res.json({
          imageUrl: `https://picsum.photos/seed/${encodedPrompt}/800/800`,
          prompt: prompt,
          isDemo: true,
          message: "Demo Rejim: Şəkil yaradıldı.",
        });
      }

      try {
        // First try Gemini image generation model
        const response = await ai.models.generateContent({
          model: "gemini-3.1-flash-lite-image",
          contents: enhancedPrompt,
          config: {
            imageConfig: {
              aspectRatio: aspectRatio || "1:1",
            },
          },
        });

        let generatedImage: string | null = null;
        if (response.candidates?.[0]?.content?.parts) {
          for (const part of response.candidates[0].content.parts) {
            if (part.inlineData?.data) {
              const mimeType = part.inlineData.mimeType || "image/png";
              generatedImage = `data:${mimeType};base64,${part.inlineData.data}`;
              break;
            }
          }
        }

        if (generatedImage) {
          return res.json({ imageUrl: generatedImage, prompt, isDemo: false });
        }
      } catch (genErr: any) {
        console.log("Using AI image generator fallback for photo generation");
      }

      // High-quality AI prompt image generation fallback (Pollinations AI)
      const cleanPrompt = encodeURIComponent(enhancedPrompt.substring(0, 200));
      const seed = Math.floor(Math.random() * 100000);
      const fallbackImageUrl = `https://image.pollinations.ai/prompt/${cleanPrompt}?width=800&height=800&seed=${seed}&nologo=true`;

      return res.json({
        imageUrl: fallbackImageUrl,
        prompt,
        isDemo: true,
        message: "SM AI tərəfindən şəkil uğurla yaradıldı.",
      });
    } catch (error: any) {
      console.error("Image Gen API Error:", error);
      res.status(500).json({ error: error.message || "Şəkil yaradılarkən xəta baş verdi." });
    }
  });

  // Serve standalone HTML file
  app.get("/sm_ai_app.html", (_req, res) => {
    res.sendFile(path.join(process.cwd(), "public", "sm_ai_app.html"));
  });

  // Serve Vite in dev or static files in production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[SM AI] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
