import React, { useState } from 'react';
import {
  Sparkles,
  Code2,
  FileText,
  Languages,
  Lightbulb,
  Download,
  Copy,
  Check,
  RefreshCw,
  Send,
  Sliders,
  Image as ImageIcon,
  Volume2,
} from 'lucide-react';
import { ImageStyle, GeneratedImageItem } from '../types';

interface CreateViewProps {
  onSendMessage: (text: string) => void;
  onNavigateToChat: () => void;
}

export const CreateView: React.FC<CreateViewProps> = ({ onSendMessage, onNavigateToChat }) => {
  const [activeSubTab, setActiveSubTab] = useState<'image' | 'code' | 'text' | 'translation' | 'business'>('image');

  // Image Gen State
  const [imagePrompt, setImagePrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState<ImageStyle>('Futuristic');
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '16:9' | '9:16'>('1:1');
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<GeneratedImageItem[]>([]);
  const [copiedPromptId, setCopiedPromptId] = useState<string | null>(null);

  // Code Gen State
  const [codePrompt, setCodePrompt] = useState('');
  const [selectedLang, setSelectedLang] = useState('React + TypeScript');

  // Text Gen State
  const [textType, setTextType] = useState('B2B E-poçt');
  const [textContent, setTextContent] = useState('');

  // Translation State
  const [sourceText, setSourceText] = useState('');
  const [targetLang, setTargetLang] = useState('İngilis dili');

  // Business Gen State
  const [businessIndustry, setBusinessIndustry] = useState('Texnologiya & AI');
  const [businessBudget, setBusinessBudget] = useState('Orta (Startap)');

  // Handle Image Generation API Call
  const handleGenerateImage = async () => {
    if (!imagePrompt.trim()) return;

    setIsGeneratingImage(true);
    try {
      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: imagePrompt,
          aspectRatio,
          style: selectedStyle,
        }),
      });

      const data = await res.json();
      if (data.imageUrl) {
        const newImg: GeneratedImageItem = {
          id: Date.now().toString(),
          prompt: imagePrompt,
          imageUrl: data.imageUrl,
          aspectRatio,
          style: selectedStyle,
          createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isDemo: data.isDemo,
        };
        setGeneratedImages((prev) => [newImg, ...prev]);
      } else {
        alert(data.error || 'Şəkil yaradıla bilmədi.');
      }
    } catch (error) {
      console.error(error);
      alert('Serverlə əlaqə zamanı xəta baş verdi.');
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedPromptId(id);
    setTimeout(() => setCopiedPromptId(null), 2000);
  };

  return (
    <div className="pb-24 pt-4 px-4 max-w-md mx-auto space-y-5">
      {/* Category Tabs Bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
        {[
          { id: 'image', label: 'Şəkil Yarat', icon: Sparkles },
          { id: 'code', label: 'Kod Yaz', icon: Code2 },
          { id: 'text', label: 'Mətn & Redaktə', icon: FileText },
          { id: 'translation', label: 'Tərcümə', icon: Languages },
          { id: 'business', label: 'Biznes İdeyaları', icon: Lightbulb },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition duration-200 ${
                isActive
                  ? 'bg-amber-500/20 border border-amber-400 text-amber-300 shadow-xs'
                  : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : ''}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. AI IMAGE GENERATOR TAB */}
      {activeSubTab === 'image' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-zinc-900 border border-amber-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-amber-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" /> SM AI Şəkil Yaratma
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 font-mono">
                Gemini Image Model
              </span>
            </div>

            {/* Prompt Input */}
            <div>
              <label className="text-[11px] font-medium text-zinc-400 block mb-1">
                Şəkil təsviri (Prompt)
              </label>
              <textarea
                value={imagePrompt}
                onChange={(e) => setImagePrompt(e.target.value)}
                placeholder="Məsələn: Qızılı neon işıqlar altında futuristik SM Global mərkəzi, 3D render..."
                rows={3}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Options Grid */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label className="text-[10px] text-zinc-400 font-medium block mb-1">Stil</label>
                <select
                  value={selectedStyle}
                  onChange={(e) => setSelectedStyle(e.target.value as ImageStyle)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2 text-xs text-zinc-200 focus:outline-none focus:border-amber-400"
                >
                  <option value="Futuristic">Futuristik</option>
                  <option value="3D Render">3D Render</option>
                  <option value="Gold Luxury">Gold Luxury</option>
                  <option value="Cyberpunk">Cyberpunk</option>
                  <option value="Photorealistic">Fotorealistik</option>
                  <option value="Minimalist Art">Minimalist Sənət</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 font-medium block mb-1">Proporsiya</label>
                <select
                  value={aspectRatio}
                  onChange={(e) => setAspectRatio(e.target.value as any)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2 text-xs text-zinc-200 focus:outline-none focus:border-amber-400"
                >
                  <option value="1:1">Kvadrat (1:1)</option>
                  <option value="16:9">Kino (16:9)</option>
                  <option value="9:16">Mobil (9:16)</option>
                </select>
              </div>
            </div>

            {/* Quick Sample Prompts */}
            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
              {[
                'Gold Cyberpunk SM AI Robot',
                'Futuristic Baku City Night Light',
                'Minimalist Golden Globe Emblem',
              ].map((sample) => (
                <button
                  key={sample}
                  onClick={() => setImagePrompt(sample)}
                  className="text-[10px] px-2.5 py-1 rounded-lg bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-amber-300 hover:border-amber-500/40 shrink-0"
                >
                  + {sample}
                </button>
              ))}
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerateImage}
              disabled={isGeneratingImage || !imagePrompt.trim()}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-black font-bold text-xs flex items-center justify-center gap-2 hover:brightness-110 active:scale-98 transition disabled:opacity-50 shadow-md"
            >
              {isGeneratingImage ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Şəkil yaradılır...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Şəkli Generasiya Et</span>
                </>
              )}
            </button>
          </div>

          {/* Generated Gallery */}
          {generatedImages.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                Yaradılmış Şəkillər ({generatedImages.length})
              </h4>
              <div className="space-y-3">
                {generatedImages.map((img) => (
                  <div
                    key={img.id}
                    className="p-3 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-2.5"
                  >
                    <div className="relative rounded-xl overflow-hidden border border-amber-500/20 bg-black">
                      <img
                        src={img.imageUrl}
                        alt={img.prompt}
                        className="w-full h-auto object-cover max-h-80"
                        referrerPolicy="no-referrer"
                      />
                      <span className="absolute top-2 right-2 text-[9px] px-2 py-0.5 rounded-full bg-black/80 text-amber-300 font-mono border border-amber-500/30">
                        {img.style} ({img.aspectRatio})
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-xs text-zinc-300 pt-1">
                      <p className="text-xs text-zinc-300 line-clamp-1 italic font-serif">
                        "{img.prompt}"
                      </p>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => handleCopy(img.prompt, img.id)}
                          className="p-1.5 rounded-lg bg-zinc-800 text-zinc-300 hover:text-amber-300"
                          title="Promptu kopyala"
                        >
                          {copiedPromptId === img.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <a
                          href={img.imageUrl}
                          download={`sm_ai_${img.id}.png`}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1.5 rounded-lg bg-amber-500/20 text-amber-300 hover:bg-amber-500/30"
                          title="Yüklə"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 2. CODE STUDIO TAB */}
      {activeSubTab === 'code' && (
        <div className="p-4 rounded-2xl bg-zinc-900 border border-amber-500/30 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-amber-300 flex items-center gap-2">
              <Code2 className="w-4 h-4 text-amber-400" /> Kod Studio & İzah
            </h3>
            <select
              value={selectedLang}
              onChange={(e) => setSelectedLang(e.target.value)}
              className="bg-zinc-950 border border-zinc-800 rounded-lg text-[11px] p-1.5 text-amber-300 focus:outline-none"
            >
              <option value="React + TypeScript">React + TypeScript</option>
              <option value="Python">Python</option>
              <option value="JavaScript / Node.js">JavaScript / Node.js</option>
              <option value="C++">C++</option>
              <option value="SQL">SQL</option>
              <option value="HTML & CSS">HTML & CSS</option>
            </select>
          </div>

          <textarea
            value={codePrompt}
            onChange={(e) => setCodePrompt(e.target.value)}
            placeholder={`${selectedLang} dilində neçə kod yazmaq və ya hansı kodu izah etmək istəyirsiniz?`}
            rows={4}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-400"
          />

          <button
            onClick={() => {
              if (!codePrompt.trim()) return;
              onSendMessage(
                `Aşağıdakı ${selectedLang} kod tapşırığını peşəkar şəkildə yaz və hər hissəsini xəta-xəta izah et:\n\n${codePrompt}`
              );
              onNavigateToChat();
            }}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-black font-bold text-xs flex items-center justify-center gap-2 hover:brightness-110 active:scale-98 transition shadow-md"
          >
            <Send className="w-4 h-4" />
            <span>Kodu Hazırla & Chat-da Gör</span>
          </button>
        </div>
      )}

      {/* 3. TEXT & EDITING TAB */}
      {activeSubTab === 'text' && (
        <div className="p-4 rounded-2xl bg-zinc-900 border border-amber-500/30 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-amber-300 flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" /> Mətn Generatoru & Redaktə
            </h3>
            <select
              value={textType}
              onChange={(e) => setTextType(e.target.value)}
              className="bg-zinc-950 border border-zinc-800 rounded-lg text-[11px] p-1.5 text-amber-300 focus:outline-none"
            >
              <option value="B2B E-poçt">B2B E-poçt</option>
              <option value="Məqalə / Blog">Məqalə / Blog</option>
              <option value="Sosial Media Postu">Sosial Media Postu</option>
              <option value="Grammar & Redaktə">Qrammatika & Redaktə</option>
              <option value="Xülasə (Summary)">Xülasə (Summary)</option>
            </select>
          </div>

          <textarea
            value={textContent}
            onChange={(e) => setTextContent(e.target.value)}
            placeholder={`${textType} üçün mövzu və ya redaktə olunacaq mətni bura yazın...`}
            rows={4}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-400"
          />

          <button
            onClick={() => {
              if (!textContent.trim()) return;
              onSendMessage(
                `Format: ${textType}\n\nAşağıdakı tələb əsasında yüksək keyfiyyətli, stilistik cəhətdən zəngin mətn yarat və ya düzəlt:\n\n${textContent}`
              );
              onNavigateToChat();
            }}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-black font-bold text-xs flex items-center justify-center gap-2 hover:brightness-110 active:scale-98 transition shadow-md"
          >
            <Send className="w-4 h-4" />
            <span>Mətni Yarat & Chat-a Göndər</span>
          </button>
        </div>
      )}

      {/* 4. TRANSLATOR TAB */}
      {activeSubTab === 'translation' && (
        <div className="p-4 rounded-2xl bg-zinc-900 border border-amber-500/30 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-amber-300 flex items-center gap-2">
              <Languages className="w-4 h-4 text-amber-400" /> Tərcüməçi
            </h3>
            <div className="flex items-center gap-1 text-xs text-amber-300">
              <span>Hədəf Dil:</span>
              <select
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value)}
                className="bg-zinc-950 border border-zinc-800 rounded-lg text-[11px] p-1.5 focus:outline-none"
              >
                <option value="İngilis dili">İngilis dili</option>
                <option value="Azərbaycan dili">Azərbaycan dili</option>
                <option value="Türkçe">Türkçe</option>
                <option value="Rus dili">Rus dili</option>
                <option value="Alman dili">Alman dili</option>
              </select>
            </div>
          </div>

          <textarea
            value={sourceText}
            onChange={(e) => setSourceText(e.target.value)}
            placeholder="Tərcümə etmək istədiyiniz mətni daxil edin..."
            rows={4}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:border-amber-400"
          />

          <button
            onClick={() => {
              if (!sourceText.trim()) return;
              onSendMessage(
                `Zəhmət olmasa aşağıdakı mətni ${targetLang} dilinə peşəkar, təbii və səlis şəkildə tərcümə et:\n\n"${sourceText}"`
              );
              onNavigateToChat();
            }}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-black font-bold text-xs flex items-center justify-center gap-2 hover:brightness-110 active:scale-98 transition shadow-md"
          >
            <Send className="w-4 h-4" />
            <span>Tərcümə Et & Chat-a Keç</span>
          </button>
        </div>
      )}

      {/* 5. BUSINESS IDEAS TAB */}
      {activeSubTab === 'business' && (
        <div className="p-4 rounded-2xl bg-zinc-900 border border-amber-500/30 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-amber-300 flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-amber-400" /> Biznes İdeyaları & Startap
            </h3>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-mono">
              SM Global Business
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-zinc-400 font-medium block mb-1">Sənaye / Sahə</label>
              <select
                value={businessIndustry}
                onChange={(e) => setBusinessIndustry(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2 text-xs text-zinc-200 focus:outline-none focus:border-amber-400"
              >
                <option value="Texnologiya & AI">Texnologiya & AI</option>
                <option value="E-ticarət & Rəqəmsal Marketinq">E-ticarət</option>
                <option value="Təhsil & FinTech">Təhsil & FinTech</option>
                <option value="Xidmət & Logistika">Xidmət & Logistika</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] text-zinc-400 font-medium block mb-1">Büdcə Səviyyəsi</label>
              <select
                value={businessBudget}
                onChange={(e) => setBusinessBudget(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2 text-xs text-zinc-200 focus:outline-none focus:border-amber-400"
              >
                <option value="Kiçik (Bootstrap)">Kiçik (Bootstrap)</option>
                <option value="Orta (Startap)">Orta (Startap)</option>
                <option value="Böyük Investisiya">Böyük İnvestisiya</option>
              </select>
            </div>
          </div>

          <button
            onClick={() => {
              onSendMessage(
                `${businessIndustry} sahəsində ${businessBudget} büdcə ilə həyata keçirilə biləcək 3 unikal, gəlirli biznes ideyası təqdim et. Hər ideya üçün:\n1. Məhsulun təsviri\n2. Hədəf auditoriya\n3. Monetizasiya modeli (Gəlir mənbəyi)\n4. Marketinq strategiyası ver.`
              );
              onNavigateToChat();
            }}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-black font-bold text-xs flex items-center justify-center gap-2 hover:brightness-110 active:scale-98 transition shadow-md"
          >
            <Lightbulb className="w-4 h-4" />
            <span>Biznes Planı Yarat</span>
          </button>
        </div>
      )}
    </div>
  );
};
