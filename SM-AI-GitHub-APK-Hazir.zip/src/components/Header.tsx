import React from 'react';
import { Cpu, Mic, Moon, Sun, Sparkles, FileCode } from 'lucide-react';
import logoImg from '../assets/images/sm_ai_logo_1786303544354.jpg';

interface HeaderProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  onOpenVoice: () => void;
  onOpenFileUpload: () => void;
  activeTab: string;
  selectedLanguage: string;
}

export const Header: React.FC<HeaderProps> = ({
  darkMode,
  setDarkMode,
  onOpenVoice,
  activeTab,
  selectedLanguage,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-zinc-950/80 dark:bg-zinc-950/90 backdrop-blur-md border-b border-amber-500/20 px-4 py-3 transition-colors duration-300">
      <div className="max-w-md mx-auto flex items-center justify-between">
        {/* Brand logo & title */}
        <div className="flex items-center gap-2.5">
          <div className="relative group cursor-pointer">
            <div className="absolute -inset-1 bg-gradient-to-r from-amber-500 to-amber-300 rounded-full blur-xs opacity-75 group-hover:opacity-100 transition duration-300"></div>
            <img
              src={logoImg}
              alt="SM AI Logo"
              className="relative w-9 h-9 rounded-full object-cover border border-amber-400/50 shadow-md"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-base font-bold bg-gradient-to-r from-amber-200 via-amber-400 to-amber-100 bg-clip-text text-transparent tracking-wide">
                SM AI
              </h1>
              <span className="px-1.5 py-0.5 text-[9px] font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded-full flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5 text-amber-400" /> PRO
              </span>
            </div>
            <p className="text-[10px] text-zinc-400 font-medium tracking-wider uppercase">
              SM Global Intelligence
            </p>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-2">
          {/* HTML Standalone Link */}
          <a
            href="/sm_ai_app.html"
            target="_blank"
            rel="noopener noreferrer"
            title="HTML Versiyasını Aç / Yüklə"
            className="p-2 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:text-amber-100 hover:bg-amber-500/20 active:scale-95 transition duration-200"
          >
            <FileCode className="w-4 h-4 text-amber-400" />
          </a>

          {/* Voice Chat shortcut button */}
          <button
            onClick={onOpenVoice}
            title="Səsli Danışıq (Voice Chat)"
            className="p-2 rounded-full bg-gradient-to-r from-amber-500/20 to-amber-600/10 border border-amber-500/30 text-amber-300 hover:text-amber-100 hover:bg-amber-500/30 active:scale-95 transition duration-200 shadow-xs"
          >
            <Mic className="w-4 h-4 text-amber-400" />
          </button>

          {/* Theme Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            title={darkMode ? 'Açıq Rejim' : 'Tünd Rejim'}
            className="p-2 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-amber-300 active:scale-95 transition duration-200"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-zinc-400" />}
          </button>
        </div>
      </div>
    </header>
  );
};
