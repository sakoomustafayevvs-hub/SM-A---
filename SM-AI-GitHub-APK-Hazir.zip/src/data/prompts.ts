import { QuickPrompt } from '../types';

export const QUICK_PROMPTS: QuickPrompt[] = [
  {
    id: 'code-1',
    title: 'React & Tailwind Komponenti',
    subtitle: 'Müasir UI kodu tərtib et',
    prompt: 'Mənə React + Tailwind CSS istifadə edərək responsive animasiyalı kard komponenti kodu yaz və izah et.',
    icon: 'Code2',
    category: 'code',
  },
  {
    id: 'business-1',
    title: 'Biznes İdeyası Yarat',
    subtitle: 'Startap və marketinq planı',
    prompt: 'Texnologiya və AI sahəsində 2026-cı il üçün gəlirli 3 biznes ideyası və marketinq strategiyası təklif et.',
    icon: 'Lightbulb',
    category: 'business',
  },
  {
    id: 'translation-1',
    title: 'Peşəkar Tərcümə',
    subtitle: 'Azərbaycan, Türk, İngilis dilli',
    prompt: 'Aşağıdakı mətni rəsmi işgüzar ingilis dilinə tərcümə et və stilini təkmilləşdir: "Bizim SM Global komandası müştərilərə ən qabaqcıl AI həllərini təqdim edir."',
    icon: 'Languages',
    category: 'translation',
  },
  {
    id: 'text-1',
    title: 'Mətn & Email Redaktəsi',
    subtitle: 'Rəsmi təklif və ya məqalə',
    prompt: 'SM Global məhsulunun təqdimatı üçün tərəfdaş şirkətlərə göndəriləcək peşəkar B2B e-poçt mətni yaz.',
    icon: 'FileText',
    category: 'text',
  },
  {
    id: 'qa-1',
    title: 'Sual-Cavab Rejimi',
    subtitle: 'İstənilən sahədə ekspert rəyi',
    prompt: 'Süni intellektin (AI) yaxın 5 ildə biznes sahələrinə edəcəyi ən böyük 5 təsiri müqayisəli izah et.',
    icon: 'HelpCircle',
    category: 'qa',
  },
  {
    id: 'image-1',
    title: 'Şəkil Yaratmaq',
    subtitle: 'Futuristik konsept dizaynı',
    prompt: 'Futuristik Bakı şəhəri, gecə vaxtı qızılı neon işıqlar, SM Global qülləsi, 3D ultra render.',
    icon: 'Sparkles',
    category: 'image',
  },
];

export const LANGUAGE_LABEL_MAP: Record<string, { name: string; flag: string; systemText: string }> = {
  az: {
    name: 'Azərbaycan',
    flag: '🇦🇿',
    systemText: 'Lütfən bütün cavabları Azərbaycan dilində səlis, rəsmi və aydın şəkildə ver.',
  },
  tr: {
    name: 'Türkçe',
    flag: '🇹🇷',
    systemText: 'Lütfen tüm yanıtları Türkçe olarak akıcı, resmi ve anlaşılır şekilde ver.',
  },
  en: {
    name: 'English',
    flag: '🇬🇧',
    systemText: 'Please provide all answers in clear, professional English.',
  },
  ru: {
    name: 'Русский',
    flag: '🇷🇺',
    systemText: 'Пожалуйста, предоставляйте все ответы на грамотном русском языке.',
  },
};
