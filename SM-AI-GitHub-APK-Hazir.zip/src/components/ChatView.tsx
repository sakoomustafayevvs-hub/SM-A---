import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Trash2,
  PlusCircle,
  Volume2,
  VolumeX,
  Copy,
  Check,
  Paperclip,
  Mic,
  Image as ImageIcon,
  Sparkles,
  Bot,
  User,
  X,
  RefreshCw,
  Code,
  FileText,
} from 'lucide-react';
import { ChatMessage, FileAttachment } from '../types';
import logoImg from '../assets/images/sm_ai_logo_1786303544354.jpg';

interface ChatViewProps {
  messages: ChatMessage[];
  onSendMessage: (
    text: string,
    image?: { base64: string; mimeType: string },
    fileContent?: { fileName: string; text: string }
  ) => void;
  onClearChat: () => void;
  onNewChat: () => void;
  isTyping: boolean;
  selectedLanguage: string;
  onOpenVoiceModal: () => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  messages,
  onSendMessage,
  onClearChat,
  onNewChat,
  isTyping,
  onOpenVoiceModal,
}) => {
  const [inputText, setInputText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [attachedImage, setAttachedImage] = useState<{ base64: string; mimeType: string; previewUrl: string } | null>(null);
  const [attachedFile, setAttachedFile] = useState<FileAttachment | null>(null);
  const [isRecordingMic, setIsRecordingMic] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Auto scroll to bottom when new messages arrive or typing status updates
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!inputText.trim() && !attachedImage && !attachedFile) return;

    // Immediately cancel any active speech synthesis when sending new question/message
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setSpeakingId(null);

    onSendMessage(
      inputText.trim(),
      attachedImage ? { base64: attachedImage.base64, mimeType: attachedImage.mimeType } : undefined,
      attachedFile ? { fileName: attachedFile.name, text: attachedFile.text || '' } : undefined
    );

    setInputText('');
    setAttachedImage(null);
    setAttachedFile(null);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (text: string, id: string) => {
    if (!('speechSynthesis' in window)) {
      alert('Sizin brauzer mətnin səsləndirilməsini dəstəkləmir.');
      return;
    }

    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Configure deep male voice (qalın oğlan səsi)
    utterance.pitch = 0.7; // Lower pitch for deep male voice
    utterance.rate = 0.95;

    const voices = window.speechSynthesis.getVoices();
    if (voices && voices.length > 0) {
      const maleVoice = voices.find((v) =>
        /male|david|pavel|stefan|george|alex|daniel|google us english|turkish male/i.test(v.name)
      );
      if (maleVoice) {
        utterance.voice = maleVoice;
      }
    }

    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  // Image Upload Handler
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Zəhmət olmasa şəkil faylı seçin.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (evt) => {
      const res = evt.target?.result as string;
      if (res) {
        setAttachedImage({
          base64: res,
          mimeType: file.type,
          previewUrl: URL.createObjectURL(file),
        });
      }
    };
    reader.readAsDataURL(file);
  };

  // File Upload Handler
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const text = evt.target?.result as string;
      setAttachedFile({
        name: file.name,
        size: file.size,
        type: file.type,
        text: text,
      });
    };
    reader.readAsText(file);
  };

  // Mic Speech Input using Web Speech API
  const handleMicInput = () => {
    // Cancel any current speech synthesis when user activates mic
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setSpeakingId(null);

    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Səsli daxiletmə brauzer tərəfindən dəstəklənmir. Düymə vasitəsilə Səsli Danışıq rejimini aça bilərsiniz.');
      onOpenVoiceModal();
      return;
    }

    try {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = 'az-AZ';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
        }
        setIsRecordingMic(true);
      };
      recognition.onresult = (event: any) => {
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
        }
        const transcript = event.results[0][0].transcript;
        setInputText((prev) => (prev ? prev + ' ' + transcript : transcript));
        setIsRecordingMic(false);
      };
      recognition.onerror = () => setIsRecordingMic(false);
      recognition.onend = () => setIsRecordingMic(false);

      recognition.start();
    } catch {
      setIsRecordingMic(false);
      onOpenVoiceModal();
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-125px)] max-w-md mx-auto">
      {/* Top Chat Toolbar */}
      <div className="flex items-center justify-between px-4 py-2 bg-zinc-950/90 border-b border-zinc-800/80">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-xs font-semibold text-zinc-300">
            SM AI Active
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20 font-mono">
            Gemini 3.6
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onNewChat}
            title="Yeni Söhbət"
            className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 active:scale-95 transition"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Yeni</span>
          </button>
          <button
            onClick={onClearChat}
            title="Söhbəti Sil"
            className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-zinc-800 transition"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3">
            <div className="w-16 h-16 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-amber-400" />
            </div>
            <h3 className="text-base font-bold text-amber-200">SM AI Söhbətinə Xoş Gelmisiniz</h3>
            <p className="text-xs text-zinc-400 max-w-xs">
              Sual verin, kod istəyin, mətn tərcümə edin və ya biznes planı hazırlamağımı tapşırın.
            </p>
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.role === 'user';

            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'} animate-fade-in`}
              >
                {/* AI Avatar */}
                {!isUser && (
                  <div className="w-8 h-8 rounded-full overflow-hidden border border-amber-400/50 shrink-0 mt-0.5">
                    <img src={logoImg} alt="SM AI" className="w-full h-full object-cover" />
                  </div>
                )}

                {/* Bubble Container */}
                <div
                  className={`max-w-[85%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed space-y-2 shadow-md ${
                    isUser
                      ? 'bg-gradient-to-r from-amber-600 to-amber-500 text-black font-medium rounded-tr-xs'
                      : 'bg-zinc-900 border border-amber-500/20 text-zinc-100 rounded-tl-xs'
                  }`}
                >
                  {/* Attached Image preview if present */}
                  {msg.image?.url && (
                    <div className="rounded-lg overflow-hidden border border-zinc-700 max-h-48 mb-2">
                      <img
                        src={msg.image.url}
                        alt="Yüklənmiş Şəkil"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  )}

                  {/* Attached File preview if present */}
                  {msg.fileContent && (
                    <div className="p-2 rounded-lg bg-black/30 border border-amber-500/30 flex items-center gap-2 mb-2 text-xs">
                      <FileText className="w-4 h-4 text-amber-400 shrink-0" />
                      <span className="truncate font-mono">{msg.fileContent.fileName}</span>
                    </div>
                  )}

                  {/* Text Content */}
                  <div className="whitespace-pre-wrap break-words font-sans">
                    {msg.content}
                  </div>

                  {/* Footer Timestamp & Message Toolbar */}
                  <div className="flex items-center justify-between pt-1 border-t border-black/10 dark:border-zinc-800/80 text-[10px] opacity-80">
                    <span className={isUser ? 'text-black/70' : 'text-zinc-500'}>
                      {msg.timestamp}
                    </span>

                    {!isUser && (
                      <div className="flex items-center gap-1.5 ml-2">
                        <button
                          onClick={() => handleCopy(msg.content, msg.id)}
                          className="p-1 hover:text-amber-300 transition"
                          title="Kopyala"
                        >
                          {copiedId === msg.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <button
                          onClick={() => handleSpeak(msg.content, msg.id)}
                          className="p-1 hover:text-amber-300 transition"
                          title="Səsləndir"
                        >
                          {speakingId === msg.id ? (
                            <VolumeX className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                          ) : (
                            <Volume2 className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* User Avatar */}
                {isUser && (
                  <div className="w-8 h-8 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center shrink-0 mt-0.5">
                    <User className="w-4 h-4 text-amber-400" />
                  </div>
                )}
              </div>
            );
          })
        )}

        {/* AI Typing Indicator */}
        {isTyping && (
          <div className="flex gap-3 justify-start items-center">
            <div className="w-8 h-8 rounded-full overflow-hidden border border-amber-400/50 shrink-0">
              <img src={logoImg} alt="SM AI" className="w-full h-full object-cover" />
            </div>
            <div className="bg-zinc-900 border border-amber-500/30 px-4 py-3 rounded-2xl rounded-tl-xs flex items-center gap-2">
              <span className="text-xs font-medium text-amber-300">SM AI düşünür</span>
              <div className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Attachments Preview Row */}
      {(attachedImage || attachedFile) && (
        <div className="px-4 py-2 bg-zinc-900/90 border-t border-zinc-800 flex items-center gap-3 overflow-x-auto">
          {attachedImage && (
            <div className="relative group shrink-0">
              <img
                src={attachedImage.previewUrl}
                alt="Attachment"
                className="w-12 h-12 rounded-lg object-cover border border-amber-400"
                referrerPolicy="no-referrer"
              />
              <button
                onClick={() => setAttachedImage(null)}
                className="absolute -top-1.5 -right-1.5 bg-rose-500 text-white rounded-full p-0.5 text-xs shadow-md"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}

          {attachedFile && (
            <div className="relative bg-zinc-800 border border-amber-500/40 p-2 rounded-lg flex items-center gap-2 text-xs text-amber-200 shrink-0">
              <FileText className="w-4 h-4 text-amber-400" />
              <span className="max-w-[120px] truncate">{attachedFile.name}</span>
              <button
                onClick={() => setAttachedFile(null)}
                className="text-zinc-400 hover:text-rose-400 ml-1"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* Input Box Area */}
      <div className="p-3 bg-zinc-950/95 border-t border-zinc-800">
        <div className="flex items-end gap-2 bg-zinc-900 border border-amber-500/30 rounded-2xl p-2 focus-within:border-amber-400 transition-all">
          {/* File Attach Buttons */}
          <div className="flex items-center gap-1 pb-1">
            {/* Hidden File Input */}
            <input
              type="file"
              ref={imageInputRef}
              onChange={handleImageSelect}
              accept="image/*"
              className="hidden"
            />
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileSelect}
              accept=".txt,.md,.js,.ts,.json,.py,.css,.html"
              className="hidden"
            />

            <button
              onClick={() => imageInputRef.current?.click()}
              title="Şəkil əlavə et"
              className="p-1.5 text-zinc-400 hover:text-amber-400 transition"
            >
              <ImageIcon className="w-4 h-4" />
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              title="Mətn faylı əlavə et"
              className="p-1.5 text-zinc-400 hover:text-amber-400 transition"
            >
              <Paperclip className="w-4 h-4" />
            </button>
          </div>

          {/* Textarea Input */}
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="SM AI-a sualınızı yazın..."
            rows={1}
            className="flex-1 bg-transparent text-xs sm:text-sm text-zinc-100 placeholder-zinc-500 resize-none focus:outline-none max-h-24 py-1.5"
          />

          {/* Mic or Send Button */}
          <div className="flex items-center gap-1 pb-1">
            <button
              onClick={handleMicInput}
              title="Səsli daxil et"
              className={`p-2 rounded-xl transition ${
                isRecordingMic
                  ? 'bg-rose-500/20 text-rose-400 animate-pulse border border-rose-500'
                  : 'text-zinc-400 hover:text-amber-400'
              }`}
            >
              <Mic className="w-4 h-4" />
            </button>

            <button
              onClick={handleSend}
              disabled={!inputText.trim() && !attachedImage && !attachedFile}
              className="p-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 text-black font-bold disabled:opacity-40 disabled:cursor-not-allowed hover:brightness-110 active:scale-95 transition"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
