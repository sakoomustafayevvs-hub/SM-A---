import React from 'react';
import {
  MessageSquare,
  Code2,
  FileText,
  Languages,
  Lightbulb,
  Sparkles,
  Upload,
  Mic,
  ArrowRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { NavTab, QuickPrompt } from '../types';
import { QUICK_PROMPTS } from '../data/prompts';
import logoImg from '../assets/images/sm_ai_logo_1786303544354.jpg';

interface HomeViewProps {
  onSelectPrompt: (promptText: string, category?: string) => void;
  setActiveTab: (tab: NavTab) => void;
  onOpenVoice: () => void;
  onOpenFileUpload: () => void;
  onOpenImageGen: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onSelectPrompt,
  setActiveTab,
  onOpenVoice,
  onOpenFileUpload,
  onOpenImageGen,
}) => {
  return (
    <div className="pb-24 pt-4 px-4 max-w-md mx-auto space-y-6">
      {/* Hero Section */}
      <div className="flex flex-col items-center text-center space-y-3 py-2">
        {/* Large Logo with glowing ring */}
        <div className="relative group cursor-pointer" onClick={() => setActiveTab('chat')}>
          <div className="absolute -inset-3 bg-gradient-to-r from-amber-500 via-amber-300 to-amber-600 rounded-full blur-md opacity-70 group-hover:opacity-100 transition duration-500 animate-pulse"></div>
          <img
            src={logoImg}
            alt="SM AI Big Logo"
            className="relative w-24 h-24 rounded-full object-cover border-2 border-amber-400 shadow-[0_0_25px_rgba(212,175,55,0.4)]"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Brand Tagline */}
        <div className="space-y-1">
          <h1 className="text-3xl font-extrabold tracking-tight text-white">
            <span className="bg-gradient-to-r from-amber-100 via-amber-300 to-amber-500 bg-clip-text text-transparent">
              SM AI
            </span>
          </h1>
          <p className="text-xs font-semibold uppercase tracking-widest text-amber-400/90 flex items-center justify-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-amber-400" /> SM Global Intelligence
          </p>
        </div>

        {/* Welcome message */}
        <div className="mt-2 bg-gradient-to-r from-zinc-900/90 via-zinc-900 to-zinc-900/90 border border-amber-500/30 p-4 rounded-2xl w-full shadow-lg backdrop-blur-md">
          <p className="text-base font-semibold text-zinc-100">
            Sənə necə kömək edə bilərəm?
          </p>
          <p className="text-xs text-zinc-400 mt-1">
            Süni intellekt ilə real söhbət edin, kod yazın, şəkil yaradın və ya biznes ideyaları hazırlayın.
          </p>
        </div>
      </div>

      {/* Primary Action Hub Grid */}
      <div className="space-y-2">
        <h2 className="text-xs font-bold text-amber-400/80 uppercase tracking-wider px-1">
          Əsas İmkanlar
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {/* Real Chat */}
          <button
            onClick={() => setActiveTab('chat')}
            className="group text-left p-3.5 rounded-2xl bg-zinc-900/80 border border-amber-500/20 hover:border-amber-400/60 transition-all duration-300 hover:shadow-[0_0_15px_rgba(212,175,55,0.15)] flex flex-col justify-between h-28"
          >
            <div className="flex items-center justify-between w-full">
              <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 group-hover:bg-amber-500 group-hover:text-black transition">
                <MessageSquare className="w-5 h-5" />
              </div>
              <ArrowRight className="w-4 h-4 text-zinc-600 group-hover:text-amber-400 transition" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-zinc-100 group-hover:text-amber-200">Real Chat</h3>
              <p className="text-[11px] text-zinc-400 line-clamp-1">AI ilə canlı söhbət et</p>
            </div>
          </button>

          {/* AI Image Generator */}
          <button
            onClick={onOpenImageGen}
            className="group text-left p-3.5 rounded-2xl bg-gradient-to-br from-zinc-900 to-amber-950/30 border border-amber-500/30 hover:border-amber-400 transition-all duration-300 hover:shadow-[0_0_20px_rgba(212,175,55,0.2)] flex flex-col justify-between h-28"
          >
            <div className="flex items-center justify-between w-full">
              <div className="p-2 rounded-xl bg-amber-400/20 text-amber-300 group-hover:bg-amber-400 group-hover:text-black transition">
                <Sparkles className="w-5 h-5" />
              </div>
              <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold">
                PRO
              </span>
            </div>
            <div>
              <h3 className="text-sm font-bold text-amber-300">Şəkil Yarat</h3>
              <p className="text-[11px] text-zinc-400 line-clamp-1">3D, Cyberpunk, Sanət</p>
            </div>
          </button>

          {/* Code & Tech */}
          <button
            onClick={() => setActiveTab('create')}
            className="group text-left p-3.5 rounded-2xl bg-zinc-900/80 border border-amber-500/20 hover:border-amber-400/60 transition-all duration-300 flex flex-col justify-between h-28"
          >
            <div className="flex items-center justify-between w-full">
              <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400 group-hover:bg-blue-500 group-hover:text-white transition">
                <Code2 className="w-5 h-5" />
              </div>
            </div>
            <div>
              <h3 className="text-sm font-bold text-zinc-100 group-hover:text-amber-200">Kod Yazmaq</h3>
              <p className="text-[11px] text-zinc-400 line-clamp-1">React, Python, SQL & İzah</p>
            </div>
          </button>

          {/* Business Ideas */}
          <button
            onClick={() => setActiveTab('create')}
            className="group text-left p-3.5 rounded-2xl bg-zinc-900/80 border border-amber-500/20 hover:border-amber-400/60 transition-all duration-300 flex flex-col justify-between h-28"
          >
            <div className="flex items-center justify-between w-full">
              <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-black transition">
                <Lightbulb className="w-5 h-5" />
              </div>
            </div>
            <div>
              <h3 className="text-sm font-bold text-zinc-100 group-hover:text-amber-200">Biznes İdeyaları</h3>
              <p className="text-[11px] text-zinc-400 line-clamp-1">Startap & Marketinq</p>
            </div>
          </button>

          {/* Voice Chat */}
          <button
            onClick={onOpenVoice}
            className="group text-left p-3.5 rounded-2xl bg-zinc-900/80 border border-amber-500/20 hover:border-amber-400/60 transition-all duration-300 flex flex-col justify-between h-28"
          >
            <div className="flex items-center justify-between w-full">
              <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 group-hover:bg-purple-500 group-hover:text-white transition">
                <Mic className="w-5 h-5" />
              </div>
            </div>
            <div>
              <h3 className="text-sm font-bold text-zinc-100 group-hover:text-amber-200">Səsli Danışıq</h3>
              <p className="text-[11px] text-zinc-400 line-clamp-1">Canlı səsli ünsiyyət</p>
            </div>
          </button>

          {/* File Upload */}
          <button
            onClick={onOpenFileUpload}
            className="group text-left p-3.5 rounded-2xl bg-zinc-900/80 border border-amber-500/20 hover:border-amber-400/60 transition-all duration-300 flex flex-col justify-between h-28"
          >
            <div className="flex items-center justify-between w-full">
              <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400 group-hover:bg-rose-500 group-hover:text-white transition">
                <Upload className="w-5 h-5" />
              </div>
            </div>
            <div>
              <h3 className="text-sm font-bold text-zinc-100 group-hover:text-amber-200">Fayl Yükləmə</h3>
              <p className="text-[11px] text-zinc-400 line-clamp-1">Mətn & Sənəd Analizi</p>
            </div>
          </button>
        </div>
      </div>

      {/* Suggested Quick Prompts */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs font-bold text-amber-400/80 uppercase tracking-wider">
            Sürətli Təkliflər
          </h2>
          <button
            onClick={() => setActiveTab('create')}
            className="text-xs text-amber-400 hover:underline flex items-center gap-1 font-medium"
          >
            Hamısı <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div className="space-y-2">
          {QUICK_PROMPTS.slice(0, 4).map((qp: QuickPrompt) => (
            <button
              key={qp.id}
              onClick={() => onSelectPrompt(qp.prompt, qp.category)}
              className="w-full text-left p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 hover:border-amber-500/40 hover:bg-zinc-800/80 transition duration-200 flex items-center justify-between group"
            >
              <div className="pr-2">
                <p className="text-xs font-semibold text-zinc-200 group-hover:text-amber-300">
                  {qp.title}
                </p>
                <p className="text-[11px] text-zinc-400 line-clamp-1">{qp.subtitle}</p>
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-zinc-500 group-hover:text-amber-400 transition transform group-hover:translate-x-0.5 shrink-0" />
            </button>
          ))}
        </div>
      </div>

      {/* SM Global Guarantee Banner */}
      <div className="p-3.5 rounded-xl bg-amber-500/5 border border-amber-500/20 flex items-center gap-3">
        <ShieldCheck className="w-8 h-8 text-amber-400 shrink-0" />
        <div>
          <p className="text-xs font-bold text-amber-200">SM Global Intelligence Təhlükəsizliyi</p>
          <p className="text-[10px] text-zinc-400 leading-tight">
            Təhlükəsiz server arxitekturası ilə məlumatlarınız qorunur. Dəqiq, sürətli və qərəzsiz AI cavabları.
          </p>
        </div>
      </div>
    </div>
  );
};
